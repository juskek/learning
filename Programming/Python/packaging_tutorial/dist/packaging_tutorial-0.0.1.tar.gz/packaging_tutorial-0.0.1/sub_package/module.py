from lib.lib import lib_function


def module_function():
    print('Hello from module')
    lib_function()
    
    