def lib_function():
    print('Hello from lib')
    