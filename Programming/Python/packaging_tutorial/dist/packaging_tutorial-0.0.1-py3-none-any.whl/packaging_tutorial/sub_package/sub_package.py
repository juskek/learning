from sub_package.module import module_function


def package_function():
    print('Hello from subpackage')
    module_function()
    